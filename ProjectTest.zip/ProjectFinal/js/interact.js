// Import Web3.js library
import Web3, { providers } from 'web3';

// Import compiled ABI of your contract
import foodChainABI from './FoodChainABI.json';

// Create a new instance of Web3.js, connecting to a local or remote Ethereum node
const web3 = new Web3(new providers.HttpProvider('http://localhost:8545')); // Replace with your Ethereum node URL

// Create a new contract instance
const contractAddress = '0x123abc'; // Replace with your deployed contract address
const foodChainContract = new web3.eth.Contract(foodChainABI, contractAddress);

// Example function to issue a certificate
async function issueCertificate(issuerAddress, proverAddress, status, foodPackID, signature) {
    try {
        const result = await foodChainContract.methods.issueCertificate(
            issuerAddress, proverAddress, status, foodPackID, signature
        ).send({ from: issuerAddress });

        console.log('Certificate issued successfully:', result);
    } catch (error) {
        console.error('Error issuing certificate:', error);
    }
}

// Example function to check if a signature matches the issuer's address
async function isMatchingSignature(message, certificateID, issuerAddress) {
    try {
        const result = await foodChainContract.methods.isMatchingSignature(message, certificateID, issuerAddress).call();

        console.log('Is signature matching:', result);
    } catch (error) {
        console.error('Error checking signature:', error);
    }
}

// Example usage
const issuerAddress = '0xissueraddress';
const proverAddress = '0xproveraddress';
const status = 'Produced';
const foodPackID = 1;
const signature = '0xsignature';
const message = '0xmessagehash';
const certificateID = 1;

issueCertificate(issuerAddress, proverAddress, status, foodPackID, signature);
isMatchingSignature(message, certificateID, issuerAddress);
