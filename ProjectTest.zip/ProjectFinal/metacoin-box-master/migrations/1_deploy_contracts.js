 const FoodChain = artifacts.require("FoodChain");

export default function(deployer) {
  deployer.deploy(FoodChain);
};
